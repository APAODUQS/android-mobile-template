package net.easysol.automation.template;

import android.os.Bundle;
import android.content.Context;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import net.easysol.did.DetectID;
import net.easysol.did.common.registration.listener.DeviceRegistrationServerResponseListener;

public class MainActivity extends AppCompatActivity {

    private Context context;
    private String url = "http://192.168.243.189:8081/detect/public/registration/mobileServices.htm?code=H57RY6EE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context = getApplicationContext();
        registerAccount();
    }

    private void showRegistrationMessage(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void registerAccount() {
        DetectID.sdk(context).didRegistration(url);
        DetectID.sdk(context)
                .setDeviceRegistrationServerResponseListener(new DeviceRegistrationServerResponseListener() {
                    @Override
                    public void onRegistrationServerResponse(String s) {
                        String message = "200".equals(s) ? "\n Device successfully registered \n" : "\n Device registration fail \n";
                        System.out.println(message);
                        showRegistrationMessage(message);
                    }
                });
    }

}
