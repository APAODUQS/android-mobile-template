package net.easysol.automation.template;


import androidx.multidex.MultiDexApplication;

import net.easysol.did.DetectID;

public class AutomationApp extends MultiDexApplication {
    @Override
    public void onCreate() {
        super.onCreate();
//        registerActivityLifecycleCallbacks(newDIDAppLifeCycleHandler());
//        context =getApplicationContext();
        DetectID.sdk(getApplicationContext()).didInit();
        DetectID.sdk(getApplicationContext()).enableSecureCertificateValidationProtocol(false);
        DetectID.sdk(getApplicationContext()).PUSH_API.enablePushAlertDefaultDialog(false);
        DetectID.sdk(getApplicationContext()).PUSH_API.enablePushTransactionDefaultDialog(false);
        DetectID.sdk(getApplicationContext()).PUSH_API.enablePushTransactionServerResponseAlerts(false);
        DetectID.sdk(getApplicationContext()).QR_API.enableQRCodeTransactionDefaultDialog(false);
        DetectID.sdk(getApplicationContext()).QR_API.enableQRCodeTransactionServerResponseAlerts(false);
        DetectID.sdk(getApplicationContext()).FACE_API.enableFaceRegistrationServerResponseAlerts(false);
        DetectID.sdk(getApplicationContext()).FACE_API.enableFaceTransactionServerResponseAlerts(false);
        DetectID.sdk(getApplicationContext()).INBOX_API.enableBadgeNumber(false);
    }

}

