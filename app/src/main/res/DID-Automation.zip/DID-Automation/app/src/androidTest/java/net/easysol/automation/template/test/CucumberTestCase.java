package net.easysol.automation.template.test;

/**
 * Created by Santiago Ruiz on 23/08/2017.
 */


import cucumber.api.CucumberOptions;


@CucumberOptions(features = "features/test.feature", // Test scenarios
        glue = {"net.easysol.automation.template.cucumber.steps"}, // Steps definitions
        format = {"pretty", // Cucumber report formats and location to store them in phone
                "html:/data/data/net.easysol.automation.template/cucumber-reports/cucumber-html-report",
                "json:/data/data/net.easysol.automation.template/cucumber-reports/cucumber.json",
                "junit:/data/data/net.easysol.automation.template/cucumber-reports/cucumber.xml"
        },
        tags = {"~@manual","@F1"}
)
// This class must be in a different package than the glue code
// (this class is in '...cucumber.test' and glue is in '...cucumber.steps')
class CucumberTestCase {
}
