package net.easysol.automation.template.cucumber.runner;

import android.content.Intent;
import android.support.test.rule.ActivityTestRule;

import net.easysol.automation.template.MainActivity;


/**
 * Created by Pedro Gutierrez on 2/14/2017.
 */

public class ActivityRule<A extends MainActivity> extends ActivityTestRule<A> {

    public static Intent intent;

    public ActivityRule(Class<A> activityClass) {
        super(activityClass, false);
    }

    @Override
    public void beforeActivityLaunched() {
        super.beforeActivityLaunched();
//        android.os.Process.killProcess(android.os.Process.myPid());
        // Maybe prepare some mock service calls
        // Maybe override some depency injection modules with mocks
    }

    @Override
    public Intent getActivityIntent() {
            intent = new Intent();
        // add some custom extras and stuff
        return intent;
    }

    @Override
    protected void afterActivityLaunched() {
        super.afterActivityLaunched();
        // maybe you want to do something here 
    }

    @Override
    protected void afterActivityFinished() {
        super.afterActivityFinished();
        // Clean up mocks
    }

    public void finishActivity() {
        this.getActivity().finish();
    }
}