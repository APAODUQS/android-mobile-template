package net.easysol.automation.template.cucumber.steps;

import android.content.Context;

import net.easysol.automation.template.Settings;

import org.junit.Assert;

import java.io.IOException;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepsDefinitions {


    private int contador;
    private Context context;

//    @Before
//    public void before() throws IOException {
//        Settings.getInstance();
//        this.context = Settings.getContext();
//    }

    @Given("^Testing (.*)$")
    public void test(String label) {
        System.out.println(label + " --------- ESTO ES UNA PRUEBA ---------");
    }

    @When("^Count to (\\d+)$")
    public void count(int counter) {
        int cuenta = 0;
        for (int i = 0; i <= counter; i++) {
            System.out.println(i + " --------- COUNT ---------");
            cuenta = i;
        }
        contador = cuenta;
    }

    @Then("^Assert number (\\d+)$")
    public void assertion(int number) {
        Assert.assertEquals(number,contador);
    }

//    @After
//    public void after() throws InterruptedException {
//        Thread.sleep(1000);
//        Settings.activityRule.finishActivity();
//    }
}
